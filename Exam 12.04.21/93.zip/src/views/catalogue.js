import { html } from '../lib.js';
import { getAllAlbums } from '../api/data.js';
// import { getUserData } from '../util.js';

const catalogueTemplate = (albums) => html `
<section id="catalogPage">
    <h1>All Albums</h1>
    ${albums.length == 0 
        ? html`<h3 class="no-articles">No Albums in Catalog!</h3>` 
        : html`<div class="card-box">
            ${albums.map(albumPreview)}
        </div>`}
</section>`;


const albumPreview = (album) => html`
<div class="card-box">
    <img src=${album.imgUrl}>
    <div>
        <div class="text-center">
            <p class="name">Name: ${album.name}</p>
            <p class="artist">Artist: ${album.artist}</p>
            <p class="genre">Genre: ${album.genre}</p>
            <p class="price">Price: $${album.price}</p>
            <p class="date">Release Date: ${album.releaseDate}</p>
        </div>
        <div class="btn-group">
            <a href="/details/${album._id}" id="details">Details</a>
        </div>
    </div>
</div>`;


export async function allListingPage(ctx) {
    const game = await getAllAlbums();
    ctx.render(catalogueTemplate(game));
}

// probvai za butona v all listing page da viknesh userdatata

// function detailsSeen() {
//     const userData = getUserData();
//     if(userData) {
//         document.getElementById('details').style.display = 'inline-block';
//     } else {
//         document.getElementById('details').style.display = 'none';
//     }
// }
// detailsSeen();